struct pstat{
  char name[16];
  char state;
  int pid;
  int ppid;
};
